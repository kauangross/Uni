#include <iostream>
#include "geometria.hpp"
#include <vector>
#include <math.h>
using namespace std;

Ponto::Ponto(float cordenadaX, float cordenadaY): x(cordenadaX), y(cordenadaY){}; // Implementação do construtor

Ponto::~Ponto(){};

void Ponto::AlterarCoordenadas(float coordenadax, float coordenaday){
    x = coordenadax;
    y = coordenaday;
}

float distancia(Ponto a, Ponto b){
    float x1 = a.getx();
    float x2 = b.getx();
    float y1 = a.gety();
    float y2 = b.gety();

    float distancia = sqrt( (x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1) );
    //cout << endl << "Distancia entre os pontos: " << distancia << endl;

    return distancia;
}

//void filtragem(vector<Ponto> a){

//}

void Ponto::mostrar(Ponto a){
    cout << "( " << a.x << ", " << a.y << " )";
}


/*void encontrarPontosMaisProximos(vector<Ponto> pontos){
    float distancia_aux;
    int qntDePontos = 3;
    float menor_distancia;
    int indice_ponto1;
    int indice_ponto2;
    menor_distancia = distancia_aux; 
    
    for (int i = 0; i < (qntDePontos - 1); i++)
    {
        for (int j = i+1; j < qntDePontos; j++)
        {
            distancia_aux = distancia(pontos[i], pontos[j]);
            cout << "Distancia entre o ponto " << i << " e o ponto " << j << ": " << distancia_aux << endl;
            if (menor_distancia >= distancia_aux)
            {
                menor_distancia = distancia_aux;
                indice_ponto1 = i;
                indice_ponto2 = j;
            }
        }
    }
    cout << "Menor distanciaaaaaaaaaaaaaaaa: ";
    pontos[indice_ponto1].mostrar(pontos[indice_ponto1]);
    cout << " e ";
    pontos[indice_ponto2].mostrar(pontos[indice_ponto2]);
};*/